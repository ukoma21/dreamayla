export { default, metadata } from "@/app/shared-dreams/page";
