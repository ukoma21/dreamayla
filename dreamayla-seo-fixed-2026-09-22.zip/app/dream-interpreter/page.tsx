import type { Metadata } from "next";
import { DreamForm } from "@/components/dream-form";
import { Footer, Header } from "@/components/site-chrome";

export const metadata: Metadata = {
  title: "Professional Dream Interpretation",
  description: "Explore your dream through symbolism, Jungian-inspired psychology, emotions, and personal context.",
  keywords: ["professional dream interpretation", "dream meaning", "dream analysis", "dream symbolism", "Jungian dream analysis", "interpret my dream", "free dream interpretation"],
  alternates: { canonical: "/dream-interpreter" },
  openGraph: {
    title: "Personal Dream Interpreter & Dream Analysis | DreamAyla",
    description: "Explore the symbols, emotions, and personal context within your dream through three thoughtful lenses.",
    url: "/dream-interpreter",
  },
};

export default function Interpreter() {
  return <><Header /><main className="page shell"><div className="pagehead"><div className="eyebrow">THE DREAMAYLA THREE-LENS METHOD</div><h1>Bring your dream into focus.</h1><p className="sectionintro">Describe what happened, how it felt, and what stayed with you. DreamAyla will explore it through ancient symbolism, Jungian-inspired psychology, and the context of your own life.</p></div><DreamForm /></main><Footer /></>;
}
