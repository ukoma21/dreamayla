import type { Metadata } from "next";
export const metadata:Metadata={title:"Your Private Dream Interpretation",robots:{index:false,follow:false}};
export default function DreamResultLayout({children}:{children:React.ReactNode}){return children;}
