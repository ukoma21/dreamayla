import type { Metadata } from "next";
export const metadata:Metadata={title:"Personal Dream Context",robots:{index:false,follow:false}};
export default function DreamQuestionsLayout({children}:{children:React.ReactNode}){return children;}
