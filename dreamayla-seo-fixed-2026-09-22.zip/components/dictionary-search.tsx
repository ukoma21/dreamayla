"use client";

import { ArrowRight, Search } from "lucide-react";
import { useRouter } from "next/navigation";
import { FormEvent, useState } from "react";

const aliases: Record<string, string> = {
  "being chased": "being-chased",
  chased: "being-chased",
  "car crash": "car-crash",
  "car accident": "car-crash",
  death: "death",
  ex: "dreaming-of-an-ex",
  "an ex": "dreaming-of-an-ex",
  "dreaming of an ex": "dreaming-of-an-ex",
  falling: "falling",
  "falling dream": "falling",
  fire: "fire",
  flying: "flying",
  house: "house",
  "being late": "late-for-something",
  "late for something": "late-for-something",
  "lost phone": "losing-your-phone",
  "losing your phone": "losing-your-phone",
  "missing a train": "missing-a-train",
  "missed train": "missing-a-train",
  "naked in public": "naked-in-public",
  pregnancy: "pregnancy",
  school: "school",
  snake: "snakes",
  snakes: "snakes",
  spider: "spiders",
  spiders: "spiders",
  teeth: "teeth-falling-out",
  "teeth falling out": "teeth-falling-out",
  trapped: "trapped",
  wedding: "wedding",
  water: "water",
  money: "money",
  poop: "falling",
};

function normalize(value: string) {
  return value.trim().toLocaleLowerCase().replace(/[^\p{L}\p{N}]+/gu, " ").trim();
}

export function DictionarySearch() {
  const router = useRouter();
  const [query, setQuery] = useState("");

  function search(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const normalized = normalize(query);
    if (!normalized) return;
    const slug = aliases[normalized] ?? normalized.replaceAll(" ", "-");
    router.push(`/dreams/${encodeURIComponent(slug)}`);
  }

  return <form className="dictionary-search" onSubmit={search} role="search">
    <Search className="icon" size={20} aria-hidden="true" />
    <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search a dream situation…" aria-label="Search a dream situation" />
    <button type="submit" disabled={!query.trim()} aria-label="Browse dream guides">Browse guides <ArrowRight size={14} /></button>
  </form>;
}
