# DreamAyla production launch

## 1. Supabase

1. Create a Supabase project and copy its URL, anon key, and service-role key into Vercel environment variables.
2. Enable Email/Password in **Authentication → Providers**.
3. Enable **Google** in **Authentication → Providers → Google**, then add the Google OAuth Client ID and Secret from Google Cloud Console.
4. Set the Site URL to `https://dreamayla.com`, and add `https://dreamayla.com/auth/callback`, `https://dreamayla.com/**`, and `http://localhost:3000/auth/callback` to Redirect URLs.
5. Configure **Authentication → SMTP Settings** with a real provider such as Resend. For Resend SMTP use host `smtp.resend.com`, port `465` or `587`, username `resend`, an API key as the password, and a sender address on a verified domain.
6. For the in-app verification-code screen, update **Authentication → Email Templates → Confirm signup** to include the `{{ .Token }}` variable. Keep `{{ .ConfirmationURL }}` in the same email so users can also confirm through the secure link if a mail client does not show the code clearly.
7. Provision a PostgreSQL database and set `DATABASE_URL` and `DIRECT_URL`. Run `npx prisma db push` once against the production database.

## 2. PayPal subscriptions

1. Create a PayPal Business app and add `PAYPAL_CLIENT_ID` / `PAYPAL_CLIENT_SECRET`.
2. Create one monthly subscription plan for Dream Journal and one for Dreamer Plus in PayPal, then add their IDs as `PAYPAL_JOURNAL_PLAN_ID` and `PAYPAL_PLUS_PLAN_ID`.
3. Register `https://YOUR_DOMAIN/api/paypal/webhook` in the PayPal Developer dashboard. Subscribe to `BILLING.SUBSCRIPTION.ACTIVATED`, `BILLING.SUBSCRIPTION.CANCELLED`, `BILLING.SUBSCRIPTION.SUSPENDED`, and `BILLING.SUBSCRIPTION.EXPIRED`.
4. Put the resulting webhook ID in `PAYPAL_WEBHOOK_ID`. Use `https://api-m.sandbox.paypal.com` during sandbox testing, then remove `PAYPAL_API_BASE` or change it to `https://api-m.paypal.com` for live payments.

## 3. Admin access

Set `ADMIN_EMAIL` to `linra612@gmail.com`. Only this verified owner account can read `/api/admin/metrics` or use `/admin`.

## 4. Vercel

Import the Git repository into Vercel, add every variable from `.env.example`, set `NEXT_PUBLIC_APP_URL` to the deployed HTTPS URL, then deploy. Do not put any server-only secrets in variables beginning with `NEXT_PUBLIC_`.

## Launch checks

- Confirm email signup and email confirmation.
- Confirm the user row is created after the first sign-in.
- Send a PayPal sandbox subscription and verify the webhook changes the user subscription state.
- Log in with the `ADMIN_EMAIL` owner account and visit `/admin`.
- Verify non-admin requests to `/api/admin/metrics` return 403.
